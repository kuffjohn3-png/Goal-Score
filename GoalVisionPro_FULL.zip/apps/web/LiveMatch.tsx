
import { useEffect, useState } from "react";
import io from "socket.io-client";

const socket = io(process.env.NEXT_PUBLIC_WS!);

export default function LiveMatch({ matchId }) {
  const [events, setEvents] = useState([]);
  const [ai, setAi] = useState("");

  useEffect(() => {
    socket.emit("joinMatch", matchId);
    socket.on("live_update", d => {
      setEvents(e => [...e, d]);
      setAi(d.explanation);
    });
  }, [matchId]);

  return (
    <div>
      <h1>Live Match Center</h1>
      <p>AI Insight: {ai}</p>
      <ul>{events.map((e,i)=><li key={i}>{e.type}</li>)}</ul>
    </div>
  );
}
