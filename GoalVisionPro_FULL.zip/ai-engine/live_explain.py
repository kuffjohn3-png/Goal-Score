
def explain(event):
    if event["type"] == "GOAL":
        return "Goal caused confidence spike"
    return "Momentum adjusted"
