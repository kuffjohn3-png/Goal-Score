
import { WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { Server } from 'socket.io';

@WebSocketGateway({ cors: true })
export class MatchGateway {
  @WebSocketServer() server: Server;

  emit(matchId: string, payload: any) {
    this.server.to(`match:${matchId}`).emit("live_update", payload);
  }
}
